/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nomina;

/**
 *
 * @author damian
 */
public class Empleado {
    private int id;
    private String nombre;
    private int plaza;
    private double horasTrabajadas;
    
    public Empleado(int id, String nombre, char plaza)
    {   this.id = id;
        this.nombre = nombre;
        this.plaza = plaza;
    }
    public Empleado()
    {   
    }
    /**
     * @return the Nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the plaza
     */
    public int getPlaza() {
        return plaza;
    }

    /**
     * @param plaza the plaza to set
     */
    public void setPlaza(int plaza) {
        this.plaza = plaza;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        switch(this.plaza)
        {   case 1: 
                return 200.0;
            case 2: 
                return 300.0;
            case 0: 
            default:
                return 100.0;
        }
        
        
        
    }

    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the horasTrabajadas
     */
    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }

    /**
     * @param horasTrabajadas the horasTrabajadas to set
     */
    public void setHorasTrabajadas(double horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }
    
    public double calcularPagoHorasExtras()
    {   double pago;
        
        if(horasTrabajadas > 40.0)
        {   switch(this.plaza)
            {   case 1: 
                    pago = 400.0 * (horasTrabajadas - 40);
                case 2: 
                    pago = 600.0 * (horasTrabajadas - 40);
                case 0: 
                default:
                    pago = 200.0 * (horasTrabajadas -40);
            }
            return pago;
        }
        else
        {   return 0.0;
        }
    }
    
    public double calcularPago()
    {   double pago;
        if(horasTrabajadas < 40.0)
        {   switch(this.plaza)
            {   case 1: 
                    pago = 200.0 * horasTrabajadas;
                    break;
                case 2: 
                    pago = 300.0 * horasTrabajadas;
                    break;
                case 0: 
                default:
                    pago = 100.0 *horasTrabajadas;
            }
        }
        else
        {   switch(this.plaza)
            {   case 1: 
                    pago = 200.0 * (horasTrabajadas + (horasTrabajadas - 40));
                    break;
                case 2: 
                    pago = 300.0 * (horasTrabajadas + (horasTrabajadas - 40));
                    break;
                case 0: 
                default:
                    pago = 100.0 * (horasTrabajadas + (horasTrabajadas - 40));
            }
        }
        return pago;
        
    }
    
   
            
    
}
