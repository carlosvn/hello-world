/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nomina;

/**
 *
 * @author damian
 */
public class Trabajador {
    private int id;
    private String nombre;
    private int plaza;
    private double horasTrabajadas;
    int EMPLEADO = 0;
    int GERENTE = 1;
    int JEFEDEPTO = 2;
    
    public Trabajador(int id, String nombre, char plaza)
    {   this.id = id;
        this.nombre = nombre;
        this.plaza = plaza;
    }
    public Trabajador()
    {   
    }
    /**
     * @return the Nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the plaza
     */
    public int getPlaza() {
        return plaza;
    }

    /**
     * @param plaza the plaza to set
     */
    public void setPlaza(int plaza) {
        this.plaza = plaza;
    }

    /**
     * @return the salario
     */
    public double getSalario() {
        switch(this.plaza)
        {   case 1: 
                return 200.0;
            case 2: 
                return 300.0;
            case 0: 
            default:
                return 100.0;
        }
        
        
        
    }

    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the horasTrabajadas
     */
    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }

    /**
     * @param horasTrabajadas the horasTrabajadas to set
     */
    public void setHorasTrabajadas(double horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }
    
    public double calcularPago()
    {   double pago;
        switch(this.plaza)
        {   case 1: 
                pago = 200.0 * horasTrabajadas;
            case 2: 
                pago = 300.0 * horasTrabajadas;
            case 0: 
            default:
                pago = 100.0 *horasTrabajadas;
        }
        if(horasTrabajadas > 40.0)
        {   return pago * 2;
        }
        else
        {   return pago;
        }
        
        
    }
    
   
            
    
}
